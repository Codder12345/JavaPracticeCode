 import java.util.*;
   class TestCase{
      public static void main(String arg[])
      {
        Scanner sc=new Scanner (System.in);
        System.out.println("Enter sample test case value");
         
      }
   }