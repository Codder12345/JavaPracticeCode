class Numbers{
public static void main(String x[])
   {
	            char ch='a';
	switch(ch)
	{
	   case 'a':
	    System.out.println("Bad");
	   break;
	  default:
	   System.out.println("Wrong choice");
	}




   }
        
}
