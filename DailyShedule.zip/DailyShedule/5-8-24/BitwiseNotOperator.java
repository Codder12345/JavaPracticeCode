public class BitwiseNotOperator{
	public static void main(String[] args) {
	 
           int d=2;
           System.out.println(d++ + d-  ++d);




	}
}
